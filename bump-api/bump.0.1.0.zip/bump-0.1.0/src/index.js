import Note from './schemas/Note.js';
import Tag from './schemas/Tag.js';
import setupServer from './server.js';
setupServer();

export {
  Note,
  Tag,
};
